# Documentation HTML Template
A Sample HTML Documentation Template for Wordpress Themes, HTML Templates and Plugins. Built with Bootstrap 3. 

## Installation
Download the package as ZIP and edit the HTML and CSS as you like.

## Demo
Click this link for a live demo : http://surjithctly.github.io/documentation-html-template/

## Donations & Support
My Brain needs two urgent coffee to continue working. Buy me a coffee or two here: https://opencollective.com/documentation-template

## Credits
This is a modified version of [Template Visual's](http://themeforest.net/user/templatevisual?ref=surjithctly&utm_source=github_surjithctly_docs) Documentation : Actual Documentation Link : http://goo.gl/RVwdHE

Browser Testing by [Browserstack](https://www.browserstack.com/)
